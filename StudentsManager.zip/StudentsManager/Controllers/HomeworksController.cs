﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentsManager.Models;

namespace StudentsManager.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeworksController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public HomeworksController(ApplicationDbContext context)
        {
            _context = context;
        }


        // Obtiene todas las calificaciones
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Homework>>> GetHomeworks()
        {
            return await _context.Homeworks.ToListAsync();
        }





        // Obtiene todas las calificaciones de un estudiante específico
        [HttpGet("ByStudent/{studentId}")]
        public async Task<ActionResult<IEnumerable<Homework>>> GetHomeworksByStudent(long studentId)
        {
            var studentExists = await _context.Students.AnyAsync(s => s.Id == studentId);
            if (!studentExists)
            {
                return NotFound("Estudiante no encontrado.");
            }

            var homeworks = await _context.Homeworks
                                        .Where(h => h.StudentId == studentId)
                                        .ToListAsync();
            return homeworks;
        }


        //Obtener Califiacion Final De Todos Los Estudiantes
        [HttpGet("FinalScores")]
        public async Task<ActionResult<IEnumerable<object>>> GetFinalScores()
        {
            var finalScores = await _context.Homeworks
                                            .GroupBy(h => h.StudentId)
                                            .Select(g => new
                                            {
                                                StudentId = g.Key,
                                                TotalScore = g.Sum(h => h.Score)
                                            })
                                            .ToListAsync();

            var result = new List<object>();

            foreach (var studentScore in finalScores)
            {
                var student = await _context.Students.FindAsync(studentScore.StudentId);
                if (student != null)
                {
                    // Poner el tope de 100 a la calificación total
                    var cappedTotalScore = Math.Min(studentScore.TotalScore, 100);

                    string finalGrade;
                    if (cappedTotalScore >= 90)
                    {
                        finalGrade = "A";
                    }
                    else if (cappedTotalScore >= 80)
                    {
                        finalGrade = "B";
                    }
                    else if (cappedTotalScore >= 70)
                    {
                        finalGrade = "C";
                    }
                    else
                    {
                        finalGrade = "F";
                    }

                    result.Add(new
                    {
                        StudentId = student.Id,
                        StudentName = student.Name,
                        TotalScore = cappedTotalScore, // Ahora se muestra el puntaje con el tope
                        FinalGrade = finalGrade
                    });
                }
            }

            return result;
        }


        // Crea una nueva calificación
        [HttpPost]
        public async Task<ActionResult<Homework>> PostHomework(Homework homework)
        {
            _context.Homeworks.Add(homework);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetHomework", new { id = homework.Id }, homework);
        }


        // Actualiza una calificación
        [HttpPut("{id}")]
        public async Task<IActionResult> PutHomework(long id, Homework homework)
        {
            if (id != homework.Id)
            {
                return BadRequest();
            }

            _context.Entry(homework).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!HomeworkExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        // Elimina una calificación
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteHomework(long id)
        {
            var homework = await _context.Homeworks.FindAsync(id);
            if (homework == null)
            {
                return NotFound();
            }

            _context.Homeworks.Remove(homework);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool HomeworkExists(long id)
        {
            return _context.Homeworks.Any(e => e.Id == id);
        }
    }
}